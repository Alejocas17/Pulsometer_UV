To simulate wav files offline in multisim.

Created in labview 2009
Tested in Multisim 11

copy all these files except the multisim example and Guitar to:
C:\Program Files\National Instruments\Circuit Design Suite 11.0\lvinstruments

It will turn up in the list of labview instruments as 'GTGenerator'
import your wav file
simulate (not real-time)

Cheers,

Gorik